// netlify/functions/scheduled-tick.js
// A Netlify Scheduled Function acts as the safety-net "heartbeat" for the
// serverless deployment: it calls the same idempotent tick() the dashboard
// triggers on every poll, so bells still get logged even if no dashboard
// browser tab happens to be open at the exact minute.
//
// LIMITATION: Netlify Scheduled Functions run on a cron schedule with
// 1-minute granularity, and the exact second within that minute is not
// guaranteed. For an always-open dashboard display (the normal setup),
// the dashboard's once-per-second polling is what gives second-accurate
// bell timing — this function is a backup for when the display is off.
// Requires a Netlify plan that supports Scheduled Functions.

const { schedule } = require('@netlify/functions');
const { makeScheduler } = require('../../lib/scheduler');
const blobStore = require('../../lib/blobStore');

const scheduler = makeScheduler(blobStore);

module.exports.handler = schedule('* * * * *', async () => {
  await scheduler.tick();
  return { statusCode: 200, body: 'ok' };
});
