// netlify/functions/api.js
// Entry point when deployed on Netlify. Same routes/behavior as the
// standalone server, but backed by Netlify Blobs instead of a local file
// (Netlify Functions have no persistent local disk and are stateless
// between invocations).
//
// netlify.toml redirects /api/* to this function, so paths inside the app
// (createApp.js) are unaffected — they still say '/api/...'.

const serverless = require('serverless-http');
const { createApp } = require('../../lib/createApp');
const blobStore = require('../../lib/blobStore');

const app = createApp(blobStore); // no staticDir: static files are served by Netlify's CDN directly

exports.handler = serverless(app);
