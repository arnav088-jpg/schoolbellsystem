// dashboard.js
// Polls the server (source of truth) for status + bell log, renders the
// control-room UI, and plays audio/voice for any bell events newer than the
// last one this browser has already seen. This design means:
//  - refreshing this page never replays a bell that already played
//  - opening this page after the PC was off does NOT dump a backlog of
//    missed bells; it just starts listening from "now" onward.

let lastSeenLogId = null; // null = not yet initialized

function pad2(n) { return n.toString().padStart(2, '0'); }
function fmtCountdown(totalSeconds) {
  if (totalSeconds == null) return '';
  const s = Math.max(0, Math.round(totalSeconds));
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
  return h > 0 ? `${pad2(h)}:${pad2(m)}:${pad2(sec)}` : `${pad2(m)}:${pad2(sec)}`;
}
function fmt12h(hhmm) {
  if (!hhmm) return '';
  let [h, m] = hhmm.split(':').map(Number);
  const ap = h >= 12 ? 'PM' : 'AM';
  h = h % 12; if (h === 0) h = 12;
  return `${h}:${pad2(m)} ${ap}`;
}

function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2600);
}

async function api(path, opts) {
  const res = await fetch(path, opts);
  return res.json();
}

function synthBeep(volume) {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const now = ctx.currentTime;
    [880, 660, 880].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.frequency.value = freq;
      osc.type = 'sine';
      gain.gain.setValueAtTime(0, now + i * 0.35);
      gain.gain.linearRampToValueAtTime(volume, now + i * 0.35 + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.35 + 0.32);
      osc.connect(gain).connect(ctx.destination);
      osc.start(now + i * 0.35);
      osc.stop(now + i * 0.35 + 0.34);
    });
  } catch (e) { console.warn('beep failed', e); }
}

function speak(text, volume) {
  if (!('speechSynthesis' in window)) return;
  const u = new SpeechSynthesisUtterance(text);
  u.volume = volume;
  u.rate = 0.95;
  window.speechSynthesis.speak(u);
}

async function playBellEvent(entry, status) {
  if (status.muted) return;
  const vol = status.volume ?? 0.8;
  const mode = entry.audioMode || 'both';

  if (mode === 'bell' || mode === 'both') {
    if (entry.soundId && entry.soundId !== 'default') {
      const player = document.getElementById('audioPlayer');
      player.src = '/api/sounds/' + entry.soundId + '/file';
      player.volume = vol;
      player.play().catch(() => {});
    } else {
      synthBeep(vol);
    }
  }
  if ((mode === 'voice' || mode === 'both') && status.voiceEnabled && entry.announcement) {
    setTimeout(() => speak(entry.announcement, vol), mode === 'both' ? 900 : 0);
  }
  showToast(`Bell: ${entry.periodName}${entry.kind !== 'scheduled' ? ' (' + entry.kind + ')' : ''}`);
}

async function pollBellLog(status) {
  const q = lastSeenLogId == null ? '' : `?sinceId=${lastSeenLogId}`;
  const data = await api('/api/bell-log' + q);
  if (lastSeenLogId == null) {
    // First load: just sync to latest, do not play a backlog.
    lastSeenLogId = data.latestId;
    renderLog((await api('/api/bell-log?sinceId=0')).items.slice(-30).reverse());
    return;
  }
  if (data.items.length) {
    for (const entry of data.items) {
      playBellEvent(entry, status);
    }
    lastSeenLogId = data.latestId;
    const full = await api('/api/bell-log?sinceId=0');
    renderLog(full.items.slice(-30).reverse());
  }
}

function renderLog(items) {
  const el = document.getElementById('logList');
  el.innerHTML = items.map(e => `
    <div class="log-item">
      <div class="t">${e.date} ${e.time}</div>
      <div class="k k-${e.kind}">${e.kind}</div>
      <div>${e.periodName}</div>
    </div>
  `).join('') || '<div class="log-item">No bells logged yet today.</div>';
}

function renderStatus(status) {
  document.getElementById('clock').textContent = status.time;
  const dateObj = new Date(status.now);
  document.getElementById('dateLine').textContent = dateObj.toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }) +
    (status.dayReason === 'holiday' ? '  •  HOLIDAY' : status.dayReason === 'non-working-day' ? '  •  NON-WORKING DAY' : status.dayReason === 'special' ? '  •  SPECIAL SCHEDULE' : '');

  const pill = document.getElementById('statusPill');
  pill.className = 'status-pill status-' + status.systemStatus;
  document.getElementById('statusText').textContent = status.systemStatus;

  document.getElementById('schoolName').textContent = status.schoolName;
  document.getElementById('volLabel').textContent = Math.round(status.volume * 100) + '%' + (status.muted ? ' (muted)' : '');
  document.getElementById('voiceLabel').textContent = status.voiceEnabled ? 'On' : 'Off';

  if (status.currentPeriod) {
    document.getElementById('currentName').textContent = status.currentPeriod.name.toUpperCase();
    document.getElementById('currentRange').textContent = `${fmt12h(status.currentPeriod.start)} – ${fmt12h(status.currentPeriod.end)}`;
    document.getElementById('countdownCurrent').textContent = 'Ends in ' + fmtCountdown(status.countdownSeconds);
  } else {
    document.getElementById('currentName').textContent = status.dayReason === 'holiday' ? 'HOLIDAY' : status.dayReason === 'non-working-day' ? 'NO SCHOOL TODAY' : 'NO ACTIVE PERIOD';
    document.getElementById('currentRange').textContent = '';
    document.getElementById('countdownCurrent').textContent = '';
  }

  if (status.nextPeriod) {
    document.getElementById('nextName').textContent = status.nextPeriod.name;
    document.getElementById('nextRange').textContent = 'Starts at ' + fmt12h(status.nextPeriod.start);
    document.getElementById('countdownNext').textContent = status.currentPeriod ? '' : 'Starts in ' + fmtCountdown(status.countdownSeconds);
  } else {
    document.getElementById('nextName').textContent = 'No more bells today';
    document.getElementById('nextRange').textContent = '';
    document.getElementById('countdownNext').textContent = '';
  }

  const nowMin = (() => { const [h, m] = status.time.split(':').map(Number); return h * 60 + m; })();
  const rows = status.todaySchedule.map(p => {
    const toMin = t => { const [h, m] = t.split(':').map(Number); return h * 60 + m; };
    const isNow = status.currentPeriod && status.currentPeriod.id === p.id;
    const isPast = toMin(p.end) <= nowMin && !isNow;
    return `<tr class="${isNow ? 'now' : isPast ? 'past' : ''}">
      <td>${p.name}</td><td>${fmt12h(p.start)}</td><td>${fmt12h(p.end)}</td>
      <td><span class="tag">${p.type}</span></td>
      <td>${isNow ? 'IN PROGRESS' : isPast ? 'Completed' : 'Upcoming'}</td>
    </tr>`;
  }).join('');
  document.getElementById('scheduleBody').innerHTML = rows || '<tr><td colspan="5">No periods scheduled today.</td></tr>';

  document.getElementById('muteBtn').textContent = status.muted ? 'Unmute' : 'Mute';
  document.getElementById('pauseBtn').textContent = status.systemStatus === 'PAUSED' ? 'Resume' : 'Pause';
}

let latestStatus = null;

async function refresh() {
  const status = await api('/api/status');
  latestStatus = status;
  renderStatus(status);
  await pollBellLog(status);
}

document.getElementById('testBtn').addEventListener('click', async () => {
  const id = latestStatus?.currentPeriod?.id || latestStatus?.nextPeriod?.id || 'p1';
  await api(`/api/test-bell/${id}`, { method: 'POST' });
});

document.getElementById('emergencyBtn').addEventListener('click', async () => {
  if (!confirm('Trigger the EMERGENCY bell now?')) return;
  await api('/api/emergency-bell', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({}) });
});

document.getElementById('muteBtn').addEventListener('click', async () => {
  await api('/api/toggle/muted', { method: 'POST' });
});

document.getElementById('pauseBtn').addEventListener('click', async () => {
  await api('/api/toggle/paused', { method: 'POST' });
});

document.getElementById('fsBtn').addEventListener('click', () => {
  if (!document.fullscreenElement) document.documentElement.requestFullscreen().catch(() => {});
  else document.exitFullscreen();
});

refresh();
setInterval(refresh, 1000);
