const DOW = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
let sounds = [];
let specialPeriods = [];

function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2600);
}
async function api(path, opts) {
  const res = await fetch(path, opts);
  return res.json();
}
async function apiJson(path, method, body) {
  return api(path, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
}

function fmt12h(hhmm) {
  if (!hhmm) return '';
  let [h, m] = hhmm.split(':').map(Number);
  const ap = h >= 12 ? 'PM' : 'AM';
  h = h % 12; if (h === 0) h = 12;
  return `${h}:${m.toString().padStart(2, '0')} ${ap}`;
}

function soundOptions(selected) {
  return sounds.map(s => `<option value="${s.id}" ${s.id === selected ? 'selected' : ''}>${s.label || s.id}</option>`).join('');
}

// ---------- System status / settings ----------
async function loadStatus() {
  const status = await api('/api/status');
  document.getElementById('systemStatusLine').textContent =
    `Current status: ${status.systemStatus} — ${status.time} — ${status.dayReason}`;
}

async function loadSettings() {
  const s = await api('/api/settings');
  document.getElementById('schoolName').value = s.schoolName;
  document.getElementById('volume').value = Math.round(s.volume * 100);
  document.getElementById('voiceEnabled').value = String(s.voiceEnabled);
  const wd = document.getElementById('workingDays');
  wd.innerHTML = DOW.map((d, i) => `<div class="chip ${s.workingDays.includes(i) ? 'active' : ''}" data-day="${i}">${d}</div>`).join('');
  wd.querySelectorAll('.chip').forEach(chip => {
    chip.addEventListener('click', () => chip.classList.toggle('active'));
  });
}

document.getElementById('saveSettings').addEventListener('click', async () => {
  const workingDays = [...document.querySelectorAll('#workingDays .chip.active')].map(c => parseInt(c.dataset.day, 10));
  await apiJson('/api/settings', 'PUT', {
    schoolName: document.getElementById('schoolName').value,
    volume: Math.max(0, Math.min(100, parseInt(document.getElementById('volume').value || '80', 10))) / 100,
    voiceEnabled: document.getElementById('voiceEnabled').value === 'true',
    workingDays
  });
  showToast('Settings saved');
});

document.getElementById('enableBtn').addEventListener('click', async () => { await apiJson('/api/toggle/systemEnabled', 'POST'); loadStatus(); });
document.getElementById('pauseBtn').addEventListener('click', async () => { await apiJson('/api/toggle/paused', 'POST'); loadStatus(); });
document.getElementById('muteBtn').addEventListener('click', async () => { await apiJson('/api/toggle/muted', 'POST'); loadStatus(); });
document.getElementById('emergencyBtn').addEventListener('click', async () => {
  const msg = prompt('Emergency announcement text:', 'Attention. This is an emergency alert.');
  if (msg === null) return;
  await apiJson('/api/emergency-bell', 'POST', { message: msg });
  showToast('Emergency bell triggered');
});

// ---------- Periods ----------
function periodRowHtml(p, editable = true) {
  return `
  <div class="period-row" data-id="${p.id}">
    <input type="text" class="f-name" value="${p.name}" />
    <input type="time" class="f-start" value="${p.start}" />
    <input type="time" class="f-end" value="${p.end}" />
    <select class="f-type">
      <option value="period" ${p.type === 'period' ? 'selected' : ''}>Period</option>
      <option value="break" ${p.type === 'break' ? 'selected' : ''}>Break</option>
      <option value="end" ${p.type === 'end' ? 'selected' : ''}>Day End</option>
    </select>
    <input type="text" class="f-announcement" value="${(p.announcement || '').replace(/"/g, '&quot;')}" />
    <select class="f-audio">
      <option value="both" ${p.audioMode === 'both' ? 'selected' : ''}>Bell + Voice</option>
      <option value="bell" ${p.audioMode === 'bell' ? 'selected' : ''}>Bell only</option>
      <option value="voice" ${p.audioMode === 'voice' ? 'selected' : ''}>Voice only</option>
    </select>
    <div>
      <button class="ghost save-period">Save</button>
      <button class="ghost test-period">Test</button>
      <button class="ghost del-period">Delete</button>
      <label style="display:inline-flex;align-items:center;gap:4px;margin:0;"><input type="checkbox" class="f-enabled" ${p.bellEnabled ? 'checked' : ''}/> On</label>
    </div>
  </div>`;
}

async function loadPeriods() {
  const periods = await api('/api/periods');
  const list = document.getElementById('periodsList');
  list.innerHTML = periods.map(p => periodRowHtml(p)).join('');

  list.querySelectorAll('.period-row').forEach(row => {
    const id = row.dataset.id;
    row.querySelector('.save-period').addEventListener('click', async () => {
      await apiJson(`/api/periods/${id}`, 'PUT', {
        name: row.querySelector('.f-name').value,
        start: row.querySelector('.f-start').value,
        end: row.querySelector('.f-end').value,
        type: row.querySelector('.f-type').value,
        announcement: row.querySelector('.f-announcement').value,
        audioMode: row.querySelector('.f-audio').value,
        bellEnabled: row.querySelector('.f-enabled').checked
      });
      showToast('Period saved');
    });
    row.querySelector('.test-period').addEventListener('click', async () => {
      await apiJson(`/api/test-bell/${id}`, 'POST');
      showToast('Test bell triggered');
    });
    row.querySelector('.del-period').addEventListener('click', async () => {
      if (!confirm('Delete this period?')) return;
      await apiJson(`/api/periods/${id}`, 'DELETE');
      loadPeriods();
    });
  });
}

document.getElementById('addPeriod').addEventListener('click', async () => {
  await apiJson('/api/periods', 'POST', { name: 'New Period', start: '08:00', end: '08:45', type: 'period', announcement: 'New period has started.', audioMode: 'both', bellEnabled: true });
  loadPeriods();
});

// ---------- Sounds ----------
async function loadSounds() {
  sounds = await api('/api/sounds');
  document.getElementById('soundsList').innerHTML = sounds.map(s => `
    <div class="pill">${s.label || s.id} ${s.id !== 'default' ? `<button class="del-sound" data-id="${s.id}">x</button>` : ''}</div>
  `).join('');
  document.querySelectorAll('.del-sound').forEach(b => b.addEventListener('click', async () => {
    await apiJson(`/api/sounds/${b.dataset.id}`, 'DELETE');
    loadSounds();
  }));
  // refresh audio dropdowns already rendered
  document.querySelectorAll('.f-sound').forEach(sel => sel.innerHTML = soundOptions(sel.value));
}

document.getElementById('uploadSoundBtn').addEventListener('click', async () => {
  const file = document.getElementById('soundFile').files[0];
  if (!file) { showToast('Choose a file first'); return; }
  const fd = new FormData();
  fd.append('sound', file);
  await fetch('/api/sounds', { method: 'POST', body: fd });
  showToast('Sound uploaded');
  loadSounds();
});

// ---------- Holidays ----------
async function loadHolidays() {
  const holidays = await api('/api/holidays');
  document.getElementById('holidaysList').innerHTML = holidays.map(d => `
    <div class="pill">${d} <button class="del-holiday" data-d="${d}">x</button></div>
  `).join('');
  document.querySelectorAll('.del-holiday').forEach(b => b.addEventListener('click', async () => {
    await apiJson(`/api/holidays/${b.dataset.d}`, 'DELETE');
    loadHolidays();
  }));
}
document.getElementById('addHoliday').addEventListener('click', async () => {
  const date = document.getElementById('holidayDate').value;
  if (!date) return;
  await apiJson('/api/holidays', 'POST', { date });
  loadHolidays();
});

// ---------- Special schedules ----------
function renderSpecialPeriods() {
  document.getElementById('specialPeriodsList').innerHTML = specialPeriods.map((p, i) => `
    <div class="period-row" data-i="${i}">
      <input type="text" class="sp-name" value="${p.name}" />
      <input type="time" class="sp-start" value="${p.start}" />
      <input type="time" class="sp-end" value="${p.end}" />
      <select class="sp-type">
        <option value="period" ${p.type === 'period' ? 'selected' : ''}>Period</option>
        <option value="break" ${p.type === 'break' ? 'selected' : ''}>Break</option>
      </select>
      <input type="text" class="sp-announcement" value="${p.announcement || ''}" />
      <select class="sp-audio">
        <option value="both">Bell + Voice</option><option value="bell">Bell only</option><option value="voice">Voice only</option>
      </select>
      <button class="ghost sp-del">Remove</button>
    </div>
  `).join('');
  document.querySelectorAll('.sp-del').forEach(b => b.addEventListener('click', (e) => {
    const i = parseInt(e.target.closest('.period-row').dataset.i, 10);
    specialPeriods.splice(i, 1);
    renderSpecialPeriods();
  }));
}
document.getElementById('addSpecialPeriod').addEventListener('click', () => {
  specialPeriods.push({ id: 'sp_' + Date.now() + '_' + specialPeriods.length, name: 'Period', start: '08:00', end: '08:45', type: 'period', announcement: '', audioMode: 'both', bellEnabled: true, soundId: 'default' });
  renderSpecialPeriods();
});
document.getElementById('saveSpecial').addEventListener('click', async () => {
  const date = document.getElementById('specialDate').value;
  const name = document.getElementById('specialName').value || 'Special Schedule';
  if (!date) { showToast('Pick a date'); return; }
  document.querySelectorAll('#specialPeriodsList .period-row').forEach((row, i) => {
    specialPeriods[i].name = row.querySelector('.sp-name').value;
    specialPeriods[i].start = row.querySelector('.sp-start').value;
    specialPeriods[i].end = row.querySelector('.sp-end').value;
    specialPeriods[i].type = row.querySelector('.sp-type').value;
    specialPeriods[i].announcement = row.querySelector('.sp-announcement').value;
    specialPeriods[i].audioMode = row.querySelector('.sp-audio').value;
  });
  await apiJson('/api/special-schedules', 'POST', { date, name, periods: specialPeriods });
  showToast('Special schedule saved');
  specialPeriods = [];
  renderSpecialPeriods();
  loadSpecialList();
});
async function loadSpecialList() {
  const list = await api('/api/special-schedules');
  document.getElementById('specialList').innerHTML = list.map(s => `
    <div class="pill">${s.date} — ${s.name} (${s.periods.length} periods) <button class="del-special" data-d="${s.date}">x</button></div>
  `).join('');
  document.querySelectorAll('.del-special').forEach(b => b.addEventListener('click', async () => {
    await apiJson(`/api/special-schedules/${b.dataset.d}`, 'DELETE');
    loadSpecialList();
  }));
}

// ---------- Backup / restore ----------
document.getElementById('exportBtn').addEventListener('click', () => {
  window.location.href = '/api/backup';
});
document.getElementById('restoreBtn').addEventListener('click', async () => {
  const file = document.getElementById('restoreFile').files[0];
  if (!file) { showToast('Choose a backup file first'); return; }
  const text = await file.text();
  try {
    const json = JSON.parse(text);
    const res = await apiJson('/api/restore', 'POST', json);
    if (res.ok) { showToast('Restored — reloading…'); setTimeout(() => location.reload(), 900); }
    else showToast('Restore failed: ' + (res.error || 'unknown error'));
  } catch (e) {
    showToast('Invalid JSON file');
  }
});

// ---------- Init ----------
async function init() {
  await loadStatus();
  await loadSettings();
  await loadSounds();
  await loadPeriods();
  await loadHolidays();
  await loadSpecialList();
  renderSpecialPeriods();
  setInterval(loadStatus, 3000);
}
init();
